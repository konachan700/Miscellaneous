package com.kanatest;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class LearnMain extends Activity {
	private class kana_array {
		public String katakana, hiragana, eng, rus;
//		public kana_array() {}
		public kana_array(String k, String h, String e, String r) {
			katakana = k;
			hiragana = h;
			eng = e;
			rus = r;
		}
	}
	
	ArrayList<kana_array> lst = new ArrayList<kana_array>();
	ArrayList<kana_array> badlst = new ArrayList<kana_array>();
	kana_array current;
	
	int mode1 = 0, mode2 = 2, cgood, cbad, currgood = 0;
	
	Button b1, b2, b3, b4, b5, b6, m1, m2, rs;
	TextView disp, tvbad, tvgood;
	
	SharedPreferences sPref;
	
	private int _rand(int min, int max) {
		double s = Math.random() * (double)max;
		int a = Integer.valueOf((int)(Math.round(s) + min));
		return a;
	}
	
	private void _get_current() {
		int a = _rand(0, lst.size()-1);
		current = lst.get(a);
		badlst.clear();
		for (int i=0; i<lst.size(); i++) {
			if (i != a) badlst.add(lst.get(i));
		}
	}
	
	private String _getChar(int modexx, kana_array e) {
		if (modexx == 0) {
			return e.katakana;
		} else if (modexx == 1) {
			return e.hiragana;
		} else if (modexx == 2) {
			return e.eng;
		} else if (modexx == 3) {
			return e.rus;
		} else {
			return "ERR";
		}
	}
	
	private void _set_btns() {
		int a = _rand(0, 5);
		currgood = a;
		b1.setText((a == 0) ? _getChar(mode2, current) : _getChar(mode2, badlst.get(_rand(0, badlst.size()-1))));
		b2.setText((a == 1) ? _getChar(mode2, current) : _getChar(mode2, badlst.get(_rand(0, badlst.size()-1))));
		b3.setText((a == 2) ? _getChar(mode2, current) : _getChar(mode2, badlst.get(_rand(0, badlst.size()-1))));
		b4.setText((a == 3) ? _getChar(mode2, current) : _getChar(mode2, badlst.get(_rand(0, badlst.size()-1))));
		b5.setText((a == 4) ? _getChar(mode2, current) : _getChar(mode2, badlst.get(_rand(0, badlst.size()-1))));
		b6.setText((a == 5) ? _getChar(mode2, current) : _getChar(mode2, badlst.get(_rand(0, badlst.size()-1))));
		disp.setText(_getChar(mode1, current));
		tvbad.setText("" + cbad);
		tvgood.setText("" + cgood);
		_unhide_btns();
	}
	
	public void _unhide_btns() {
		b1.setVisibility(Button.VISIBLE);
		b2.setVisibility(Button.VISIBLE);
		b3.setVisibility(Button.VISIBLE);
		b4.setVisibility(Button.VISIBLE);
		b5.setVisibility(Button.VISIBLE);
		b6.setVisibility(Button.VISIBLE);
	}
	
	private void _inc_mode(int m) {
		if (m == 1) {
			mode1++;
			if (mode1 > 3) mode1 = 0;
		} else if (m == 2) {
			mode2++;
			if (mode2 > 3) mode2 = 0;
		}
		
		Editor ed = sPref.edit();
		ed.putInt("mode1", mode1); 
		ed.putInt("mode2", mode2); 
		ed.commit();
		
		_get_current();
		_set_btns();
	}
	
	private void _test(int t) {
		if (t == currgood) {
			cgood++;
			_get_current();
			_set_btns();
		} else {
			cbad++;
			tvbad.setText("" + cbad);
		}
		Editor ed = sPref.edit();
		ed.putInt("cgood", cgood); 
		ed.putInt("cbad", cbad); 
		ed.commit();
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_learn_main);
		
		// MAIN GROUP **********************************************
		lst.add(new kana_array("ン", "ん", "n",   "н"));
		lst.add(new kana_array("ワ", "わ", "wa",  "ва"));
		lst.add(new kana_array("カ", "か", "ka",  "ка"));
		lst.add(new kana_array("ラ", "ら", "ra",  "ра"));
		lst.add(new kana_array("ヤ", "や", "ya",  "я"));
		lst.add(new kana_array("マ", "ま", "ma",  "ма"));
		lst.add(new kana_array("ハ", "は", "ha",  "ха"));
		lst.add(new kana_array("ナ", "な", "na",  "на"));
		lst.add(new kana_array("タ", "た", "ta",  "та"));
		lst.add(new kana_array("サ", "さ", "sa",  "са"));
		lst.add(new kana_array("ア", "あ", "a",   "а"));
		lst.add(new kana_array("イ", "い", "i",   "и"));
		lst.add(new kana_array("リ", "り", "ri",  "ри"));
		lst.add(new kana_array("ミ", "み", "mi",  "ми"));
		lst.add(new kana_array("ヒ", "ひ", "hi",  "хи"));
		lst.add(new kana_array("ニ", "に", "ni",  "ни"));
		lst.add(new kana_array("チ", "ち", "ti",  "ти"));
		lst.add(new kana_array("シ", "し", "shi", "си"));
		lst.add(new kana_array("キ", "き", "ki",  "ки"));
		lst.add(new kana_array("ル", "る", "ru",  "ру"));
		lst.add(new kana_array("ユ", "ゆ", "yu",  "ю"));
		lst.add(new kana_array("ム", "む", "mu",  "му"));
		lst.add(new kana_array("フ", "ふ", "fu",  "фу"));
		lst.add(new kana_array("ヌ", "ぬ", "nu",  "ну"));
		lst.add(new kana_array("ツ", "つ", "tsu", "цу"));
		lst.add(new kana_array("ス", "す", "su",  "су"));
		lst.add(new kana_array("ク", "く", "ku",  "ку"));
		lst.add(new kana_array("ウ", "う", "u",   "у"));
		lst.add(new kana_array("エ", "え", "e",   "э"));
		lst.add(new kana_array("レ", "れ", "re",  "рэ"));
		lst.add(new kana_array("メ", "め", "me",  "мэ"));
		lst.add(new kana_array("ヘ", "へ", "he",  "хэ"));
		lst.add(new kana_array("ネ", "ね", "ne",  "нэ"));
		lst.add(new kana_array("テ", "て", "te",  "тэ"));
		lst.add(new kana_array("セ", "せ", "se",  "сэ"));
		lst.add(new kana_array("ケ", "け", "ke",  "кэ"));
		lst.add(new kana_array("オ", "お", "o",   "о"));
		lst.add(new kana_array("ロ", "ろ", "ro",  "ро"));
		lst.add(new kana_array("ヨ", "よ", "yo",  "ё"));
		lst.add(new kana_array("モ", "も", "mo",  "мо"));
		lst.add(new kana_array("ホ", "ほ", "ho",  "хо"));
		lst.add(new kana_array("ノ", "の", "no",  "но"));
		lst.add(new kana_array("ト", "と", "to",  "то"));
		lst.add(new kana_array("ソ", "そ", "so",  "со"));
		lst.add(new kana_array("コ", "こ", "ko",  "ко"));
		lst.add(new kana_array("ヲ", "を", "wo",  "во"));
		// ADDITIONAL GROUP **********************************************
		// lst.add(new kana_array("", "", "", ""));
		
		//****************************************************************

		b1 = (Button) findViewById(R.id.b1);
		b2 = (Button) findViewById(R.id.b2);
		b3 = (Button) findViewById(R.id.b3);
		b4 = (Button) findViewById(R.id.b4);
		b5 = (Button) findViewById(R.id.b5);
		b6 = (Button) findViewById(R.id.b6);
		
		m1 = (Button) findViewById(R.id.m1);
		m2 = (Button) findViewById(R.id.m2);
		rs = (Button) findViewById(R.id.reset);
		
		disp = (TextView) findViewById(R.id.display);
		
		tvbad  = (TextView) findViewById(R.id.bad_num);
		tvgood = (TextView) findViewById(R.id.good_num);
		
		sPref = getSharedPreferences("learnkana_a", MODE_PRIVATE);
		mode1 = sPref.getInt("mode1", 0);
		mode2 = sPref.getInt("mode2", 2);
		cgood = sPref.getInt("cgood", 0);
		cbad  = sPref.getInt("cbad",  0);
		
		_get_current();
		_set_btns();
		
		m1.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { _inc_mode(1); }});
		m2.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { _inc_mode(2); }});
		
		rs.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { 
			Editor ed = sPref.edit();
			ed.putInt("cgood", 0); 
			ed.putInt("cbad", 0); 
			cgood = 0;
			cbad = 0;
			ed.commit();
			_get_current();
			_set_btns();
		}});
		
		b1.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { b1.setVisibility(Button.INVISIBLE); _test(0); }});
		b2.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { b2.setVisibility(Button.INVISIBLE); _test(1); }});
		b3.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { b3.setVisibility(Button.INVISIBLE); _test(2); }});
		b4.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { b4.setVisibility(Button.INVISIBLE); _test(3); }});
		b5.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { b5.setVisibility(Button.INVISIBLE); _test(4); }});
		b6.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { b6.setVisibility(Button.INVISIBLE); _test(5); }});
	}
/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.learn_main, menu);
		return true;
	}
*/
}
